const Buttons = (props) => {
  return (
    <div className="buttons">
      <button onClick={() => props.changeColor("red")}>red</button>
      <button onClick={() => props.changeColor("green")}>green</button>
      <button onClick={() => props.changeColor("blue")}>blue</button>
    </div>
  );
};

export default Buttons
