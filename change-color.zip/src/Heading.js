const Heading = props => {
    return <h2 className={props.textColor}>{props.textColor}</h2>
}

export default Heading