import "./App.css";

import { useEffect, useState } from "react";
import Heading from "./Heading";
import Buttons from "./Buttons";

const App = () => {
  const [textColor, setTextColor] = useState("blue");

  useEffect(() => {
    getData();
  }, []);

  const changeColor = (color) => {
    setTextColor(color);
  };

  const getData = () => {
    console.log("pobieram");
  };

  return (
    <div className="App">
      <Heading textColor={textColor} />
      <Buttons changeColor={changeColor} />
    </div>
  );
};

export default App;
